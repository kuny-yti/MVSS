#include "ui_composer.h"

ui_composer::ui_composer(const piwidget &ui)
{

}
