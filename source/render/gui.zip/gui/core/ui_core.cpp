#include "ui_core.h"

// 排序根节点，用于排列选中的先后顺序
void tWidgetManages::sqrt(iwidget *ui)
{
    if (ui->parent() != NULL)
        return;

    for (uint i = 0; i < root.count(); ++i)
        if (ui == root[i])
            root.move(i, 0);
}
// 向根节点添加父部件
bool tWidgetManages::append(iwidget *p)
{
    if (root.contains (p))
        return false;
    if (p->parent() == NULL)
    {
        root.append (p);
        return true;
    }
    return false;
}
// 向根节点删除父部件
bool tWidgetManages::remove(iwidget *oui)
{
    //! 若是删除根对象则其他子对象全部删除
    if (oui && (oui->parent() == NULL))
    {
        for (uint i = 0; i < root.count(); ++i)
        {
            if (root[i] == oui)
            {
                root.remove(i);
                return true;
            }
        }
    }
    return false;
}

// 根据事件所在的父部件进行事件派遣
bool tWidgetManages::dispatch(const bs_event &evt)
{
    bool dispret = false;

    // 若激活部件为真则有部件还在事件模式状态
    if (active)
        dispret = posting(active, evt);
    // 当前有焦点对象则将事件下发到焦点对象，用于键盘事件
    else if (focus && (evt.key () != Event_KeyNot || focus->contains (fpoint(evt.x(), evt.y()))))
        dispret = posting(focus, evt);
    // 当鼠标进入窗口后又进入到子部件中，此时则记录的窗口对象
    else if (ui_parent && ui_parent->contains (fpoint(evt.x(), evt.y())))
    {
        if (enter && enter->contains (fpoint(evt.x(), evt.y())))
            dispret = posting(enter, evt);
        else
            dispret = posting(ui_parent, evt);
    }
    /*else if (enter && enter->contains (fpoint(evt.x(), evt.y())))
        dispret = posting(enter, evt);*/
    else
    {
        ui_parent = NULL;
        enter = NULL;
        foreach (iwidget * &wg , root)
        {
            // 若鼠标位置在指定部件内则将其设为进入状态
            if (wg->contains (fpoint(evt.x(), evt.y())))
            {
                if (!ui_parent || (ui_parent && ui_parent->type &Ui_Window))
                {
                    ui_parent = wg;
                    leave = NULL;
                }
                dispret = posting(wg, evt);
                break;
            }
            else if (!wg->is_hide () && !wg->is_freeze ())
                wg->state = Ui_Normal;
        }
    }
    // 排序当前被激活的窗口部件
    if (active && (active->type & Ui_Window))
        sqrt (active);

    if (!dispret && focus)
    {
        focus->state = Ui_Normal;
        focus = NULL;
    }

    return dispret;
}
bool tWidgetManages::posting(iwidget *gui, const bs_event &evt)
{
    bool outR = false;
    // 若为隐藏则不处理部件事件
    if (gui->is_hide ())
        return true;

    if (!active)
    {
        // 接受本组件下的子组件处理部件事件
        for (bs_object::child uw = gui->begin(); uw != gui->end(); ++uw)
        {
            iwidget *fake = bsAsCast(iwidget *) (*uw);
            if (fake->contains (fpoint(evt.x(), evt.y())))
                outR |= posting(fake, evt);
            else if (!fake->is_hide () || !gui->is_freeze ())
                fake->state = Ui_Normal;
        }
    }

    if (!outR)
    {
        if (enter != gui)
            leave = enter;
        enter = gui;

        return gui->event (evt);
        // 父部件响应
        /*if ((gui->parent() == NULL) && (gui->type & Ui_Window))
            return evtwindow (evt, gui);
        // 本部件为子部件响应-扩展部件也需要响应
        else if (gui->parent() && ((gui->type & Ui_Widget) || (gui->type & Ui_Extension)))
        {
            iwidget *tmp_parent = gui->parent ()->as<iwidget>();
            // 当本部件和父对象都为部件时需要对父部件进行时间响应
            if (tmp_parent && tmp_parent->type & Ui_Widget)
                return evtwidget (evt, tmp_parent);
            return evtwidget(evt, gui);
        }*/
    }
    // 子部件返回，若是false说明子部件没有响应，若为true则子部件响应
    return outR;
}

void tWidgetManages::render(float width, float height)
{
    // 处理焦点控件
    if (focus && (focus != active))
        focus->state = Ui_Focus;

    //! 取反序原因是，OpenGL 渲染原因
    for (int i = root.count()-1; i >= 0 ; --i)
        paint(root[i], width, height);

    // 绘制置顶部件
    if (top)
        paint(top, width, height);

    if (dump != Dump_Not)
    {
        //! 取反序原因是，OpenGL 渲染原因
        for (int i = root.count()-1; i >= 0 ; --i)
        {
            root[i]->dump ();
            for (bs_object::child it = root[i]->begin(); it != root[i]->end(); ++it)
            {
                iwidget *renui = (*it)->as<iwidget>();
                if (renui)
                    renui->dump ();
            }
        }

        // 绘制置顶部件
        if (top)
            top->dump ();
    }
}
void tWidgetManages::paint (iwidget *gui, float width, float height)
{
    //! 若对象为隐藏则不绘制
    if (!gui->is_hide())
    {
        gui->paint();

        //! 根据根节点id 渲染子节点
        for (bs_object::child it = gui->begin(); it != gui->end(); ++it)
        {
            iwidget *renui = (*it)->as<iwidget>();
            if (renui)
                paint(renui, width, height);
        }
    }
}
