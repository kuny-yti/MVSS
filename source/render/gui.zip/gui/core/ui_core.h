#ifndef UI_CORE_H
#define UI_CORE_H

#include "gui/iwidget.h"


#endif // UI_CORE_H
