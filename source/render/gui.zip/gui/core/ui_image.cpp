#include "ui_image.h"

ui_image::ui_image(iwidget *parent):
    ui_state(parent)
{

}
