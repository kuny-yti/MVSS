#include "ui_text.h"

ui_text::ui_text(iwidget *parent):
    ui_state(parent)
{

}
