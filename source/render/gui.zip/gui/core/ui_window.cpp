#include "ui_window.h"

ui_window::ui_window(iwidget *parent):
    ui_state(parent)
{

}
ui_window::~ui_window()
{

}
